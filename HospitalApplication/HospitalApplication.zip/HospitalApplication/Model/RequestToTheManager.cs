using System;

namespace Model
{
   public class RequestToTheManager
   {
      private String Request;
      private String OperationStart;
      private String OperationEnd;
   
   }
}