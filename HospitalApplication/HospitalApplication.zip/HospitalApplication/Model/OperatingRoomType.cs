using System;

namespace Model
{
   public enum OperatingRoomType
   {
      OperatingRoomForMinorInterventions,
      peratingRoomForGeneralSurgery,
      OperatingRoomForCardiacSurgery,
      OperatingRoomForNeuroSurgery,
      OperatingRoomForDentistry,
      OperatingRoomForGynecology
   
   }
}