using System;

namespace Model
{
   public enum RoomType
   {
      Office,
      RestRoom,
      OperatingRoom
   
   }
}