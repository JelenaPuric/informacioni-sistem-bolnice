using System;

namespace Model
{
   public class ExaminationType
   {
      //private EnumConstant Operation;
      //private EnumConstant RegularExamination;
   
   }
}