using System;

namespace Model
{
    public enum TypeOfPerson
    {
        Doctor,
        Patient,
        Manager,
        Secretary
    }
}