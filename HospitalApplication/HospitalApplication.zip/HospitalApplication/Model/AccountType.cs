/***********************************************************************
 * Module:  AccountType.cs
 * Author:  ranin
 * Purpose: Definition of the Class Model.AccountType
 ***********************************************************************/

using System;

namespace Model
{
   public enum AccountType
   {
      permanentAccount,
      guestAccount
   }
}